# Commit Scope Memo (2026-04-20)

## Context

This memo records an unexpected commit scope expansion while executing a requested 3-commit workflow with hook bypass enabled (`--no-verify`).

- Requested sequence:
  1. RL non-stub training changes (`GRID-main`)
  2. command-bus v1 slice (`CascadeProjects/Components/shared-types`)
  3. routine schema promotion (`workspace/racks/routines/*/routine.yaml`)

- Operator explicitly authorized hook bypass due failing hook network resolution.

## Intended Scope for Commit #1

Commit only these files in `GRID-main`:

- `src/grid/agentic/training_loop.py`
- `src/grid/agentic/policy.py`
- `research/experiments/rl/dispatch.py`

## Actual Commit Created

- Commit: `2cc792a`
- Message: `feat(agentic-rl): enable replay-buffer-backed training updates`
- Branch: `main` (in `CascadeProjects/Projects/GRID-main`)

Observed result:

- **36 files changed**
- **3528 insertions**, **272 deletions**
- Included many staged files beyond intended 3 (docs, tests, config, hooks, lockfile, RL collateral).

## Evidence Reference

Snapshot command:

```bash
git -C ~/workspace/CascadeProjects/Projects/GRID-main show --stat --oneline 2cc792a
```

Returned summary includes (abridged):

- `.claude/settings.local.json`
- `.env.example`
- `.githooks/pre-commit`
- `config/prompts/*`
- `research/experiments/rl/*` (multiple files)
- `src/grid/agentic/*` (multiple files)
- `tests/agentic/rl/*` (multiple files)
- `uv.lock`

## Cause

The repository already had a large staged set before the targeted commit command.  
`git commit` with bypass proceeded with the full staged index, not only the intended subset.

## Current Position

- Commit `2cc792a` exists and is recorded.
- Work was paused immediately after detection to prevent further unintended history changes.
- Requested options were presented to the operator; selected action was to generate this memo for continuity and references.

## Recovery Paths (Operator Decision Needed)

1. **Keep as-is** and continue with follow-up commits.
2. **Rewrite/split history** to isolate intended commit scope (requires explicit destructive-history authorization).
3. **Add corrective follow-up commit(s)** without rewriting existing commit.

## Notes for Future Execution

- Before each atomic commit, confirm staged scope explicitly:
  - `git diff --cached --name-only`
- Stage exact files immediately before commit:
  - `git add <explicit files>`
- Recheck staged set:
  - `git status --short`
- Then commit.

