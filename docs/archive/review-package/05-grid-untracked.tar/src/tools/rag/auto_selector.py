"""Auto-select an Ollama model for a task from the curated catalog.

The selector is a pure function over the catalog (no side effects, no network).
It matches a :class:`TaskRequest` against every known :class:`ModelEntry` and
returns the best-scoring candidate plus a :class:`SelectionTrace` explaining
why. Under UNPROVISIONED MODE the ``cloud`` scope is automatically excluded
per the catalog's ``selection_rules.unprovisioned_excludes``.

Typical use:

.. code-block:: python

    from tools.rag.auto_selector import TaskRequest, select

    choice = select(TaskRequest(task_type="code_reasoning"))
    print(choice.entry.name, choice.trace.reason)

Integration with ``llm/factory.py`` lives behind the existing
``RAG_LLM_MODE=auto`` path — this module provides the pick, the factory turns
the pick into a :class:`BaseLLMProvider`.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Literal

from .model_catalog import Catalog, ModelEntry, load_catalog

logger = logging.getLogger(__name__)

Scope = Literal["local", "cloud", "auto"]
TaskType = str  # free-form to match catalog's task_to_capability keys

# Ranking weights — tuneable via catalog.selection_rules in a later pass.
_SOURCE_SCORE = {"local": 100, "cloud-bridged": 60, "cloud": 20, "unknown": 10}
_SPEED_SCORE = {"fast": 20, "medium": 10, "cloud-offloaded": 5, "cloud": 3, "unknown": 0}
_SIZE_SCORE = {"small": 5, "medium": 10, "large": 15, "xlarge": 20, "unknown": 0}


@dataclass
class TaskRequest:
    """A single request for a model pick.

    Attributes:
        task_type: Category key in ``catalog.task_to_capability`` (e.g.
            ``"chat"``, ``"reasoning"``, ``"code"``, ``"vision"``,
            ``"tool_use"``, ``"embed"``).
        scope: ``"local"``, ``"cloud"``, or ``"auto"``. ``"auto"`` filters by
            UNPROVISIONED state.
        attributes: Optional hints. Supported keys:
            ``min_context``, ``specialization``, ``family``, ``size_class``,
            ``thinking_required`` (bool), ``tools_required`` (bool),
            ``vision_required`` (bool).
        session_category: Free-form label (e.g. ``"interactive"``,
            ``"batch"``, ``"safety"``). Used as a soft hint via
            ``attributes`` when provided.
    """

    task_type: TaskType = "chat"
    scope: Scope = "auto"
    attributes: dict[str, object] = field(default_factory=dict)
    session_category: str | None = None


@dataclass
class SelectionTrace:
    """Explanation of why a model was picked."""

    reason: str
    candidates_considered: int
    scores: list[tuple[str, int]]  # (model_name, score) highest first
    rejected: list[tuple[str, str]]  # (model_name, why_rejected)


@dataclass
class Selection:
    """Result of :func:`select`."""

    entry: ModelEntry
    trace: SelectionTrace


def _unprovisioned() -> bool:
    """Detect UNPROVISIONED MODE.

    The workspace rule is: localhost only, no external network. We honor an
    explicit env flag first, then fall back to a conservative default.
    """
    flag = os.environ.get("CASCADE_UNPROVISIONED", "").lower()
    if flag in {"1", "true", "yes"}:
        return True
    if flag in {"0", "false", "no"}:
        return False
    # Default: assume UNPROVISIONED unless the user says otherwise.
    return True


def _matches_scope(entry: ModelEntry, scope: Scope) -> bool:
    if scope == "local":
        return entry.source == "local"
    if scope == "cloud":
        return entry.source in {"cloud", "cloud-bridged"}
    # scope == "auto": honour UNPROVISIONED exclusions from the catalog
    if _unprovisioned():
        return entry.source == "local"
    return True


def _capability_match_score(entry: ModelEntry, required: list[str]) -> int | None:
    """Return a match score or ``None`` if a required capability is missing."""
    if not required:
        return 0
    missing = [cap for cap in required if not entry.supports(cap)]
    if missing:
        return None
    # Bonus for exact coverage (no extra capabilities): a model with exactly
    # the needed capabilities is preferred over one with broader (and
    # potentially heavier) coverage.
    extra = len(set(entry.capabilities) - set(required))
    return 100 * len(required) - extra


def _attribute_score(entry: ModelEntry, attrs: dict[str, object]) -> tuple[int, list[str]]:
    """Score optional attribute preferences. Returns (score, reject_reasons)."""
    score = 0
    rejects: list[str] = []

    min_context = attrs.get("min_context")
    if isinstance(min_context, int):
        if entry.context_window is None:
            score -= 5  # unknown context window is mildly penalised
        elif entry.context_window < min_context:
            rejects.append(f"context_window<{min_context}")
        else:
            score += 10

    specialization = attrs.get("specialization")
    if isinstance(specialization, str) and entry.specialization == specialization:
        score += 25

    family = attrs.get("family")
    if isinstance(family, str) and entry.family == family:
        score += 15

    size_class = attrs.get("size_class")
    if isinstance(size_class, str) and entry.size_class == size_class:
        score += 10

    if attrs.get("thinking_required") is True:
        if entry.thinking_mode is None:
            rejects.append("thinking_required but thinking_mode=None")
        else:
            score += 30

    if attrs.get("tools_required") is True and "tools" not in entry.capabilities:
        rejects.append("tools_required but tools not in capabilities")
    elif attrs.get("tools_required") is True:
        score += 20

    if attrs.get("vision_required") is True and "vision" not in entry.capabilities:
        rejects.append("vision_required but vision not in capabilities")
    elif attrs.get("vision_required") is True:
        score += 20

    return score, rejects


def _final_score(entry: ModelEntry, task_match: int, attr_score: int) -> int:
    base = task_match + attr_score
    base += _SOURCE_SCORE.get(entry.source, 0)
    base += _SPEED_SCORE.get(entry.speed_tier, 0)
    base += _SIZE_SCORE.get(entry.size_class, 0)
    return base


def select(request: TaskRequest, *, catalog: Catalog | None = None) -> Selection:
    """Pick the best model for ``request`` from the catalog.

    The function is pure — it never contacts Ollama — so callers are free to
    wrap it in whatever caching / circuit-breaker they already have for the
    factory path.
    """

    cat = catalog or load_catalog()
    required_caps = cat.capability_for_task(request.task_type)

    scored: list[tuple[int, ModelEntry]] = []
    rejected: list[tuple[str, str]] = []

    for entry in cat.all_models():
        if not _matches_scope(entry, request.scope):
            rejected.append((entry.name, f"scope={request.scope} rejected source={entry.source}"))
            continue

        task_score = _capability_match_score(entry, required_caps)
        if task_score is None:
            missing = [c for c in required_caps if not entry.supports(c)]
            rejected.append((entry.name, f"missing_capabilities={missing}"))
            continue

        attr_score, attr_rejects = _attribute_score(entry, request.attributes)
        if attr_rejects:
            rejected.append((entry.name, ";".join(attr_rejects)))
            continue

        total = _final_score(entry, task_score, attr_score)
        scored.append((total, entry))

    scored.sort(key=lambda pair: pair[0], reverse=True)

    if not scored:
        # Fallback to 'simple' per selection_rules.fallback_on_empty — we
        # surface a synthetic entry so callers can still pick a provider.
        fallback_name = cat.selection_rules.get("fallback_on_empty", "simple")
        synthetic = ModelEntry(
            name=fallback_name,
            source="local",
            family=fallback_name,
            capabilities=("chat",),
            notes="Synthetic fallback — no catalog model matched the request.",
        )
        trace = SelectionTrace(
            reason=f"no-match-fallback -> {fallback_name}",
            candidates_considered=len(cat.all_models()),
            scores=[],
            rejected=rejected,
        )
        logger.warning(
            "auto_selector.no_match task=%s scope=%s attrs=%s",
            request.task_type,
            request.scope,
            request.attributes,
        )
        return Selection(entry=synthetic, trace=trace)

    best_score, best_entry = scored[0]
    trace = SelectionTrace(
        reason=(
            f"task={request.task_type} "
            f"caps={required_caps} "
            f"scope={request.scope} "
            f"score={best_score} "
            f"source={best_entry.source}"
        ),
        candidates_considered=len(cat.all_models()),
        scores=[(entry.name, score) for score, entry in scored],
        rejected=rejected,
    )
    logger.info(
        "auto_selector.selected",
        extra={
            "task": request.task_type,
            "scope": request.scope,
            "model": best_entry.name,
            "score": best_score,
        },
    )
    return Selection(entry=best_entry, trace=trace)


__all__ = [
    "Scope",
    "Selection",
    "SelectionTrace",
    "TaskRequest",
    "select",
]
