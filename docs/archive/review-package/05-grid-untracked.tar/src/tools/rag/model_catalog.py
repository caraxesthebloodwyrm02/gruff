"""Load, query, and refresh the Ollama model catalog.

The catalog at ``config/ollama-model-catalog.json`` is structured around the
segments of Ollama's official documentation (Cloud, Thinking, Vision,
Embeddings, Tool Calling, Web Search). See ``source_docs`` inside the catalog
for the authoritative URLs.

Design goals:

* **Docs-aligned schema.** Capability metadata mirrors Ollama's docs 1:1, so new
  sections in the docs slot in as new ``capabilities`` keys without touching
  downstream code.
* **UNPROVISIONED-safe.** Live ``/api/tags`` queries against local Ollama are
  always allowed. Cloud / web_fetch refreshes are network-gated and skipped
  unless explicitly enabled.
* **User overrides preserved.** An optional sibling file
  ``ollama-model-catalog.overrides.json`` is merged on top of the managed
  catalog and never overwritten by ``refresh_catalog``.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_DEFAULT_CATALOG_NAME = "ollama-model-catalog.json"
_DEFAULT_OVERRIDES_NAME = "ollama-model-catalog.overrides.json"
_CATALOG_PATH_ENV = "GRID_OLLAMA_MODEL_CATALOG"


@dataclass(frozen=True)
class ModelEntry:
    """A single model record (local or cloud)."""

    name: str
    source: str  # "local" | "cloud-bridged" | "cloud"
    family: str
    capabilities: tuple[str, ...]
    thinking_mode: str | None = None  # None | "boolean" | "level"
    thinking_levels: tuple[str, ...] = ()
    specialization: str = "general"
    context_window: int | None = None
    size_class: str = "unknown"
    speed_tier: str = "unknown"
    dimension: int | None = None
    notes: str = ""
    docs_refs: tuple[str, ...] = ()
    last_seen: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    def supports(self, capability: str) -> bool:
        return capability in self.capabilities


@dataclass
class Catalog:
    """Parsed view of the catalog JSON."""

    schema_version: str
    generated_at: str
    source_docs: dict[str, str]
    capabilities: dict[str, dict[str, Any]]
    task_to_capability: dict[str, list[str]]
    local_models: dict[str, ModelEntry]
    cloud_models: dict[str, ModelEntry]
    selection_rules: dict[str, Any]
    refresh: dict[str, Any]
    path: Path

    def all_models(self) -> list[ModelEntry]:
        """Return every known model (local first, then cloud)."""
        return [*self.local_models.values(), *self.cloud_models.values()]

    def capability_for_task(self, task: str) -> list[str]:
        """Return the list of capabilities required for a task category."""
        return list(self.task_to_capability.get(task, ["chat"]))

    def capability_meta(self, capability: str) -> dict[str, Any]:
        """Return the docs-aligned metadata for a capability."""
        return dict(self.capabilities.get(capability, {}))


def _find_catalog_path() -> Path:
    """Locate the catalog JSON.

    Lookup order:

    1. Env var ``GRID_OLLAMA_MODEL_CATALOG`` (absolute path).
    2. Walk up from this file until ``config/ollama-model-catalog.json`` is found.
    """

    env_path = os.environ.get(_CATALOG_PATH_ENV)
    if env_path:
        p = Path(env_path)
        if p.is_file():
            return p

    here = Path(__file__).resolve().parent
    for ancestor in [here, *here.parents]:
        candidate = ancestor / "config" / _DEFAULT_CATALOG_NAME
        if candidate.is_file():
            return candidate

    msg = (
        f"{_DEFAULT_CATALOG_NAME} not found. Set {_CATALOG_PATH_ENV} or place "
        f"the file under the GRID project's config/ directory."
    )
    raise FileNotFoundError(msg)


def _parse_entry(name: str, raw: dict[str, Any]) -> ModelEntry:
    return ModelEntry(
        name=name,
        source=raw.get("source", "unknown"),
        family=raw.get("family", "unknown"),
        capabilities=tuple(raw.get("capabilities", [])),
        thinking_mode=raw.get("thinking_mode"),
        thinking_levels=tuple(raw.get("thinking_levels", [])),
        specialization=raw.get("specialization", "general"),
        context_window=raw.get("context_window"),
        size_class=raw.get("size_class", "unknown"),
        speed_tier=raw.get("speed_tier", "unknown"),
        dimension=raw.get("dimension"),
        notes=raw.get("notes", ""),
        docs_refs=tuple(raw.get("docs_refs", [])),
        last_seen=raw.get("last_seen"),
        raw=raw,
    )


def _strip_hints(block: dict[str, Any]) -> dict[str, Any]:
    """Drop metadata keys like ``_hint`` before parsing model entries."""
    return {k: v for k, v in block.items() if not k.startswith("_")}


def _merge_overrides(base: dict[str, Any], overrides: dict[str, Any]) -> dict[str, Any]:
    """Deep-merge ``overrides`` into ``base``, with overrides winning."""
    out: dict[str, Any] = dict(base)
    for key, value in overrides.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge_overrides(out[key], value)
        else:
            out[key] = value
    return out


def load_catalog(path: Path | None = None) -> Catalog:
    """Parse the catalog JSON into a :class:`Catalog`."""

    catalog_path = path or _find_catalog_path()
    with catalog_path.open() as f:
        raw = json.load(f)

    overrides_path = catalog_path.with_name(_DEFAULT_OVERRIDES_NAME)
    if overrides_path.is_file():
        try:
            with overrides_path.open() as f:
                overrides = json.load(f)
            raw = _merge_overrides(raw, overrides)
            logger.info("model_catalog.overrides_applied", extra={"path": str(overrides_path)})
        except Exception as exc:  # pragma: no cover — defensive only
            logger.warning("model_catalog.overrides_failed: %s", exc)

    models = raw.get("models", {})
    local = {
        name: _parse_entry(name, entry)
        for name, entry in _strip_hints(models.get("local", {})).items()
    }
    cloud = {
        name: _parse_entry(name, entry)
        for name, entry in _strip_hints(models.get("cloud", {})).items()
    }

    return Catalog(
        schema_version=raw.get("schema_version", "0"),
        generated_at=raw.get("generated_at", ""),
        source_docs=dict(raw.get("source_docs", {})),
        capabilities=dict(raw.get("capabilities", {})),
        task_to_capability=dict(raw.get("task_to_capability", {})),
        local_models=local,
        cloud_models=cloud,
        selection_rules=dict(raw.get("selection_rules", {})),
        refresh=dict(raw.get("refresh", {})),
        path=catalog_path,
    )


# ---------------------------------------------------------------------------
# Refresh routine


def _probe_local_tags(base_url: str, timeout_ms: int) -> list[dict[str, Any]]:
    """Live ``GET /api/tags`` against a local Ollama; safe under UNPROVISIONED."""
    try:
        with httpx.Client(timeout=timeout_ms / 1000.0) as client:
            resp = client.get(f"{base_url.rstrip('/')}/api/tags")
            resp.raise_for_status()
            return list(resp.json().get("models", []))
    except (httpx.HTTPError, httpx.TimeoutException, OSError) as exc:
        logger.warning("model_catalog.local_probe_failed: %s", exc)
        return []


def refresh_catalog(
    *,
    base_url: str = "http://localhost:11434",
    include_cloud: bool = False,
    include_docs: bool = False,
    path: Path | None = None,
) -> Catalog:
    """Refresh the managed sections of the catalog.

    The ``models.local`` block is rewritten from a live ``/api/tags`` response.
    Capability/attribute overrides that already exist for a known model name are
    preserved; unknown local models get a minimal stub entry that the user can
    enrich (or that a later refresh with ``include_docs=True`` can annotate).

    Cloud and docs refreshes require external network and are gated. When
    running under UNPROVISIONED MODE (localhost only) keep both flags off.
    """

    catalog_path = path or _find_catalog_path()
    with catalog_path.open() as f:
        raw = json.load(f)

    # ----- Local probe (always safe) ---------------------------------------
    live_models = _probe_local_tags(base_url, timeout_ms=5000)
    now = datetime.now(UTC).isoformat()
    existing_local = _strip_hints(raw.get("models", {}).get("local", {}))
    new_local: dict[str, Any] = {}
    # Preserve the _hint key if present
    original_local_block = raw.get("models", {}).get("local", {})
    if "_hint" in original_local_block:
        new_local["_hint"] = original_local_block["_hint"]

    live_names: set[str] = set()
    for model in live_models:
        name = model.get("name")
        if not name:
            continue
        live_names.add(name)

        if name in existing_local:
            # Preserve hand-edited metadata, update only last_seen
            entry = dict(existing_local[name])
            entry["last_seen"] = now
            new_local[name] = entry
        else:
            # Minimal stub for a freshly-pulled model
            new_local[name] = {
                "family": name.split(":")[0].split("-")[0],
                "source": "local",
                "capabilities": ["chat", "generate"],
                "specialization": "general",
                "size_class": "unknown",
                "speed_tier": "unknown",
                "notes": "Auto-added by refresh_catalog; enrich capabilities as needed.",
                "docs_refs": ["index"],
                "last_seen": now,
            }

    # Keep orphaned entries around (for models recently removed) but mark them
    for name, entry in existing_local.items():
        if name not in live_names and name not in new_local:
            entry = dict(entry)
            entry.setdefault("notes", "")
            entry["notes"] = f"(stale: not in last /api/tags probe at {now}) {entry['notes']}".strip()
            new_local[name] = entry

    if "models" not in raw:
        raw["models"] = {}
    raw["models"]["local"] = {k: v for k, v in new_local.items() if v is not None}

    # ----- Cloud probe (blocked under UNPROVISIONED) -----------------------
    if include_cloud:
        logger.info("model_catalog.cloud_refresh requested (network-gated; not implemented until network is restored)")
        # Intentional no-op — will be implemented when UNPROVISIONED lifts.
        # Shape: GET https://ollama.com/api/tags with Bearer $OLLAMA_API_KEY.

    # ----- Docs refresh (blocked under UNPROVISIONED) ---------------------
    if include_docs:
        logger.info("model_catalog.docs_refresh requested (network-gated; not implemented until network is restored)")
        # Intentional no-op — will use web_fetch / ollama.web_fetch against
        # the URLs in source_docs to re-hydrate capabilities metadata.

    raw["generated_at"] = now

    tmp_path = catalog_path.with_suffix(f".tmp.{os.getpid()}")
    with tmp_path.open("w") as f:
        json.dump(raw, f, indent=2)
        f.write("\n")
    tmp_path.replace(catalog_path)
    logger.info(
        "model_catalog.refreshed",
        extra={"local_count": len(live_names), "path": str(catalog_path)},
    )

    return load_catalog(catalog_path)


__all__ = [
    "Catalog",
    "ModelEntry",
    "load_catalog",
    "refresh_catalog",
]
