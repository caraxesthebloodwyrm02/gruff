from __future__ import annotations

import pytest

from application.mothership.config import SecuritySettings
from application.mothership.security.secret_validation import SecretValidationError


class TestSecuritySettingsValidation:
    def test_missing_secret_is_critical_in_production(self) -> None:
        settings = SecuritySettings(secret_key="", cors_origins=[], rate_limit_enabled=True)

        issues = settings.validate(environment="production", fail_fast=False)

        assert any("MOTHERSHIP_SECRET_KEY is not set" in issue for issue in issues)
        assert issues[0].startswith("CRITICAL:"), "Critical production issues should be surfaced first"

    def test_missing_secret_raises_in_production_fail_fast(self) -> None:
        settings = SecuritySettings(secret_key="", cors_origins=[], rate_limit_enabled=True)

        with pytest.raises(SecretValidationError, match="MOTHERSHIP_SECRET_KEY is not set"):
            settings.validate(environment="production", fail_fast=True)

    def test_cors_wildcard_is_critical_in_production(self) -> None:
        settings = SecuritySettings(
            secret_key="test-secret-key-at-least-32-chars-long-placeholder",
            cors_origins=["*"],
            rate_limit_enabled=True,
        )

        issues = settings.validate(environment="production", fail_fast=False)

        assert any("CORS wildcard (*) detected" in issue for issue in issues)
        assert any(issue.startswith("CRITICAL:") for issue in issues)

    def test_rate_limiting_disabled_warns_in_production(self) -> None:
        settings = SecuritySettings(
            secret_key="test-secret-key-at-least-32-chars-long-placeholder",
            cors_origins=["https://example.com"],
            rate_limit_enabled=False,
        )

        issues = settings.validate(environment="production", fail_fast=False)

        assert any("Rate limiting is disabled" in issue for issue in issues)
        assert not any("CRITICAL: Rate limiting is disabled" == issue for issue in issues)

    def test_development_mode_surfaces_non_critical_warnings(self) -> None:
        settings = SecuritySettings(secret_key="", cors_origins=["*"], rate_limit_enabled=False)

        issues = settings.validate(environment="development", fail_fast=False)

        assert any("MOTHERSHIP_SECRET_KEY is not set" in issue for issue in issues)
        assert any("CORS wildcard (*) detected" in issue for issue in issues)
        assert any("Rate limiting is disabled (development mode)" in issue for issue in issues)
        assert not any(issue.startswith("CRITICAL:") for issue in issues)
