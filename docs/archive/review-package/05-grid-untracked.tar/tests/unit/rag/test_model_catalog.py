"""Tests for tools.rag.model_catalog and tools.rag.auto_selector.

Covers:
  * Catalog load (default path + explicit path)
  * ModelEntry.supports()
  * Catalog.capability_for_task / capability_meta
  * Auto-selector scope filters (local / cloud / auto+UNPROVISIONED)
  * Task-based capability matching
  * Attribute-based filtering (thinking_required, tools_required, vision_required)
  * Synthetic fallback when no match
  * refresh_catalog local-probe path with mocked httpx
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from tools.rag.auto_selector import TaskRequest, select
from tools.rag.model_catalog import (
    Catalog,
    ModelEntry,
    load_catalog,
    refresh_catalog,
)


_MINIMAL_CATALOG: dict = {
    "schema_version": "1.0",
    "generated_at": "2026-04-20T00:00:00+00:00",
    "source_docs": {
        "index": "https://docs.ollama.com/llms.txt",
        "thinking": "https://docs.ollama.com/thinking",
    },
    "capabilities": {
        "chat": {"endpoint": "/api/chat", "response_field": "message.content"},
        "embed": {"endpoint": "/api/embed", "response_field": "embeddings"},
        "thinking": {"opt_in_field": "think"},
        "tools": {"opt_in_field": "tools"},
        "vision": {"opt_in_field": "images"},
    },
    "task_to_capability": {
        "chat": ["chat"],
        "reasoning": ["chat", "thinking"],
        "embed": ["embed"],
        "tool_use": ["chat", "tools"],
        "vision": ["chat", "vision"],
    },
    "models": {
        "local": {
            "_hint": "managed section",
            "gemma4:latest": {
                "family": "gemma4",
                "source": "local",
                "capabilities": ["chat", "vision"],
                "specialization": "general",
                "speed_tier": "fast",
                "size_class": "medium",
                "context_window": 8192,
            },
            "qwen3-coder-next:cloud": {
                "family": "qwen3",
                "source": "cloud-bridged",
                "capabilities": ["chat", "tools", "thinking"],
                "thinking_mode": "boolean",
                "specialization": "code",
                "size_class": "large",
                "speed_tier": "cloud-offloaded",
                "context_window": 32768,
            },
        },
        "cloud": {
            "gpt-oss:120b-cloud": {
                "family": "gpt-oss",
                "source": "cloud",
                "capabilities": ["chat", "thinking", "tools"],
                "thinking_mode": "level",
                "thinking_levels": ["low", "medium", "high"],
                "specialization": "general",
                "size_class": "xlarge",
                "speed_tier": "cloud",
            },
            "embeddinggemma": {
                "family": "gemma",
                "source": "cloud",
                "capabilities": ["embed"],
                "dimension": 768,
            },
        },
    },
    "selection_rules": {
        "fallback_on_empty": "simple",
        "unprovisioned_excludes": ["cloud", "cloud-bridged"],
    },
    "refresh": {"enabled": True},
}


@pytest.fixture
def catalog_file(tmp_path: Path) -> Path:
    """Write a minimal catalog JSON and return its path."""
    path = tmp_path / "ollama-model-catalog.json"
    path.write_text(json.dumps(_MINIMAL_CATALOG))
    return path


@pytest.fixture
def catalog(catalog_file: Path) -> Catalog:
    return load_catalog(catalog_file)


# ---------------------------------------------------------------------------
# load_catalog


def test_load_catalog_parses_sections(catalog: Catalog):
    assert catalog.schema_version == "1.0"
    assert "index" in catalog.source_docs
    assert "chat" in catalog.capabilities
    assert "embed" in catalog.capabilities
    assert set(catalog.local_models) == {"gemma4:latest", "qwen3-coder-next:cloud"}
    assert set(catalog.cloud_models) == {"gpt-oss:120b-cloud", "embeddinggemma"}


def test_load_catalog_strips_hint_keys(catalog: Catalog):
    # "_hint" is metadata, not a model entry
    assert "_hint" not in catalog.local_models


def test_model_entry_supports(catalog: Catalog):
    gemma = catalog.local_models["gemma4:latest"]
    assert gemma.supports("chat")
    assert gemma.supports("vision")
    assert not gemma.supports("embed")


def test_capability_for_task_default(catalog: Catalog):
    assert catalog.capability_for_task("reasoning") == ["chat", "thinking"]
    # unknown task → ["chat"] default
    assert catalog.capability_for_task("unknown-task") == ["chat"]


def test_capability_meta(catalog: Catalog):
    meta = catalog.capability_meta("embed")
    assert meta["endpoint"] == "/api/embed"


def test_load_catalog_applies_overrides(tmp_path: Path, catalog_file: Path):
    overrides_path = catalog_file.parent / "ollama-model-catalog.overrides.json"
    overrides_path.write_text(
        json.dumps(
            {
                "models": {
                    "local": {
                        "gemma4:latest": {
                            "specialization": "user-override-specialization",
                        }
                    }
                }
            }
        )
    )
    cat = load_catalog(catalog_file)
    assert cat.local_models["gemma4:latest"].specialization == "user-override-specialization"


# ---------------------------------------------------------------------------
# auto_selector.select


def test_select_chat_unprovisioned_prefers_local(catalog: Catalog):
    with patch.dict("os.environ", {"CASCADE_UNPROVISIONED": "1"}):
        choice = select(TaskRequest(task_type="chat"), catalog=catalog)
    assert choice.entry.name == "gemma4:latest"
    assert choice.entry.source == "local"


def test_select_reasoning_unprovisioned_excludes_cloud_bridged(catalog: Catalog):
    """Under UNPROVISIONED, cloud-bridged models must be excluded even though
    qwen3-coder-next:cloud is the only thinking-capable local-listed model."""
    with patch.dict("os.environ", {"CASCADE_UNPROVISIONED": "1"}):
        choice = select(TaskRequest(task_type="reasoning"), catalog=catalog)
    # No local-source thinking model present → synthetic fallback
    assert choice.entry.source in {"local"}  # synthetic fallback is source="local"
    assert choice.entry.name == "simple"
    assert "no-match-fallback" in choice.trace.reason


def test_select_reasoning_with_network_picks_thinking_model(catalog: Catalog):
    with patch.dict("os.environ", {"CASCADE_UNPROVISIONED": "0"}):
        choice = select(TaskRequest(task_type="reasoning"), catalog=catalog)
    assert "thinking" in choice.entry.capabilities


def test_select_scope_cloud_skips_local(catalog: Catalog):
    with patch.dict("os.environ", {"CASCADE_UNPROVISIONED": "0"}):
        choice = select(TaskRequest(task_type="chat", scope="cloud"), catalog=catalog)
    assert choice.entry.source in {"cloud", "cloud-bridged"}


def test_select_embed_task_picks_embedder(catalog: Catalog):
    with patch.dict("os.environ", {"CASCADE_UNPROVISIONED": "0"}):
        choice = select(TaskRequest(task_type="embed"), catalog=catalog)
    assert "embed" in choice.entry.capabilities


def test_select_attribute_tools_required_rejects_non_tool_models(catalog: Catalog):
    with patch.dict("os.environ", {"CASCADE_UNPROVISIONED": "1"}):
        choice = select(
            TaskRequest(task_type="chat", attributes={"tools_required": True}),
            catalog=catalog,
        )
    # gemma4 doesn't support tools, so fallback applies under UNPROVISIONED
    assert choice.entry.name == "simple"


def test_select_attribute_vision_required_picks_vision_model(catalog: Catalog):
    with patch.dict("os.environ", {"CASCADE_UNPROVISIONED": "1"}):
        choice = select(
            TaskRequest(task_type="vision", attributes={"vision_required": True}),
            catalog=catalog,
        )
    assert choice.entry.name == "gemma4:latest"


def test_select_attribute_specialization_bonus(catalog: Catalog):
    # Within a single source tier (scope="cloud" here), specialization should
    # tip the scoring. gemma4 (local) would otherwise dominate via source
    # weighting — confirm the tie-breaker only operates once that's removed.
    with patch.dict("os.environ", {"CASCADE_UNPROVISIONED": "0"}):
        choice = select(
            TaskRequest(
                task_type="chat",
                scope="cloud",
                attributes={"specialization": "code"},
            ),
            catalog=catalog,
        )
    assert choice.entry.specialization == "code"


def test_select_attribute_min_context_rejects_small_models(catalog: Catalog):
    with patch.dict("os.environ", {"CASCADE_UNPROVISIONED": "1"}):
        choice = select(
            TaskRequest(
                task_type="chat",
                attributes={"min_context": 100000},  # xlarge-only
            ),
            catalog=catalog,
        )
    # No local model meets min_context under UNPROVISIONED
    assert choice.entry.name == "simple"


def test_select_trace_records_rejections(catalog: Catalog):
    with patch.dict("os.environ", {"CASCADE_UNPROVISIONED": "1"}):
        choice = select(
            TaskRequest(task_type="tool_use", attributes={"tools_required": True}),
            catalog=catalog,
        )
    # gemma4 should appear as rejected because it lacks "tools"
    rejected_names = {name for name, _ in choice.trace.rejected}
    assert "gemma4:latest" in rejected_names


# ---------------------------------------------------------------------------
# refresh_catalog


def test_refresh_catalog_adds_new_live_models(catalog_file: Path):
    """A freshly-pulled model that's not in the catalog gets a stub entry."""

    class _FakeResp:
        def __init__(self, payload):
            self._payload = payload

        def raise_for_status(self):  # pragma: no cover — trivial
            pass

        def json(self):
            return self._payload

    class _FakeClient:
        def __init__(self, *_, **__):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def get(self, url):
            return _FakeResp(
                {
                    "models": [
                        {"name": "gemma4:latest"},
                        {"name": "brand-new:model"},
                    ]
                }
            )

    with patch("tools.rag.model_catalog.httpx.Client", _FakeClient):
        cat = refresh_catalog(path=catalog_file)

    assert "brand-new:model" in cat.local_models
    new_entry = cat.local_models["brand-new:model"]
    assert new_entry.source == "local"
    assert "chat" in new_entry.capabilities


def test_refresh_catalog_preserves_existing_metadata(catalog_file: Path):
    """Refresh must not overwrite hand-edited capability/specialization."""

    class _FakeResp:
        def raise_for_status(self):  # pragma: no cover — trivial
            pass

        def json(self):
            return {"models": [{"name": "gemma4:latest"}]}

    class _FakeClient:
        def __init__(self, *_, **__):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def get(self, url):
            return _FakeResp()

    with patch("tools.rag.model_catalog.httpx.Client", _FakeClient):
        cat = refresh_catalog(path=catalog_file)

    gemma = cat.local_models["gemma4:latest"]
    assert gemma.specialization == "general"  # preserved from minimal catalog
    assert gemma.context_window == 8192  # preserved
    # last_seen is updated
    assert gemma.last_seen is not None
