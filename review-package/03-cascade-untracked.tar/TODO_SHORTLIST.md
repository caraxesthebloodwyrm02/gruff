# TODO Shortlist — Real, Current, Outcome-Producing Items

This shortlist is the result of triaging the TODO Tree to the highest-impact, lowest-effort items. It excludes stale docs, provisioning placeholders, platform-specific noise, and already-resolved items.

| Priority | Type | File | Outcome |
|---|---|---|---|---|
| P1 | Security test gap | `tests/security/test_security_suite.py` | Unskip and pass request-signature validation test (debug validation logic, ensure RATE_LIMIT_SECRET is configured) |
| P1 | Security test gap | `tests/security/test_security_suite.py` | Unskip and stabilize full security pipeline test (resolve Redis mock AsyncMock incompatibility) |
| P1 | API guardrail | `tests/api/test_phase3_security_guardrails.py` | Verify generic error responses do not leak stack traces (resolve pytest capturing issue) |
| P1 | Runtime security | `src/application/mothership/config/__init__.py` | Enforce secure secret-key behavior (set MOTHERSHIP_SECRET_KEY, ensure minimum 64-character strength) |
| P1 | Runtime security | `src/application/mothership/config/__init__.py` | Tighten CORS production safeguards (replace wildcard `*` with explicit origins in MOTHERSHIP_CORS_ORIGINS) |
| P1 | Runtime security | `src/application/mothership/config/__init__.py` | Tighten rate-limiting production safeguards (enable MOTHERSHIP_RATE_LIMIT_ENABLED for production) |

## Classification

- **Keep Now** (all items above): active code/tests, verifiable outcomes, not blocked by external provisioning, direct security value
- **Keep Later**: training loop held-out evaluation, navigation module gaps (defer until those areas are active)
- **Hide as Noise**: Stripe `TODO(you)` env vars, Windows-specific skips, doc checklists, OpenClaw items (resolved), stale interpreter paths
- **Archive as Resolved**: OpenClaw gateway cleanup (stopped, disabled, removed, verified)

## Verification Paths

- **Test gaps**: `uv run pytest tests/security/test_security_suite.py tests/api/test_phase3_security_guardrails.py -v`
- **Secret key**: check `MOTHERSHIP_SECRET_KEY` env var and validate via `validate_secret_strength()`
- **CORS**: verify `MOTHERSHIP_CORS_ORIGINS` contains explicit origins, not `*`
- **Rate limiting**: verify `MOTHERSHIP_RATE_LIMIT_ENABLED=true` in production

## Success Criteria

This shortlist is successful when:

- All 6 items have concrete verification steps
- Each item maps to a single file and a single outcome
- No stale provisioning or doc-only items remain in the working set
- The list fits in a single screen without scrolling
