# Signal Automation System

## Overview

The Signal Automation System provides automated signal handling with decorated mock responses to reduce attack surface area and mitigate risks from wide-open interactive code and tools. The system:

- **Classifies incoming signals** by risk level (critical, high, medium, low)
- **Generates decorated mock responses** appropriate to each signal type
- **Schedules automated routines** using cron expressions
- **Maintains signal history** for audit and analysis
- **Reduces surface area** by providing controlled responses instead of direct execution

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Signal Automation Engine                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────┐    ┌─────────────────┐    ┌─────────────────┐  │
│  │SignalRisk   │    │MockResponse     │    │Automation      │  │
│  │Classifier   │    │Decorator        │    │Scheduler       │  │
│  └─────────────┘    └─────────────────┘    └─────────────────┘  │
│        ▲                  ▲  ▲  ▲                  ▲            │
│        │                  │  │  │                  │            │
│  ┌─────┴─────┐          │  │  │  ┌─────────────────┐ │            │
│  │Signal       │          │  │  │  │Mock Response    │ │            │
│  │Metadata      │          │  │  │  │Templates        │ │            │
│  └─────────────┘          │  │  │  └─────────────────┘ │            │
│                            │  │  │                    │            │
│                            └──┴──┘                    │            │
│                                                   │            │
│                                                   │            │
│                                            ┌──────┴──────┐    │
│                                            │Decorated    │    │
│                                            │Response     │    │
│                                            └──────────────┘    │
│                                                                      │
└─────────────────────────────────────────────────────────────────┘
```

## Components

### 1. SignalRiskClassifier

Classifies incoming signals based on content and metadata:

- **Critical**: Contains keywords like `root`, `sudo`, `admin`, `password`, `secret`, `token`, `execute`, `shell`, `command`, `inject`, `bypass`, `override`
- **High**: Contains keywords like `config`, `settings`, `database`, `network`, `file`, `write`, `delete`, `modify`, `update`, `access`, `permission`
- **Medium**: Contains keywords like `read`, `query`, `status`, `info`, `list`, `get`, `check`, `verify`
- **Low**: No sensitive keywords detected

### 2. MockResponseDecorator

Generates decorated mock responses with:

- **Template-based responses**: Predefined response patterns for each signal type
- **Dynamic interpolation**: Signal metadata inserted into response templates
- **Risk-appropriate responses**: Different templates based on risk level
- **Response decoration**: Metadata about the mock response including risk level and confidence score

### 3. AutomationScheduler

Manages scheduled automation routines using cron expressions:

- **Cron parsing**: Simple cron expression support (`*/5 * * * *` for every 5 minutes)
- **Routine management**: Add, enable/disable, and execute scheduled routines
- **Due checking**: Determine which routines should run at the current time

### 4. SignalAutomationEngine

Orchestrates the automation system:

- **Signal processing**: Classify, decorate, and respond to signals
- **History tracking**: Store signal metadata for audit purposes
- **Template management**: Register and manage mock response templates
- **Scheduling**: Setup and run automated routines

## Signal Types

The system handles these signal types:

- `api_request`: API calls and HTTP requests
- `tool_invocation`: Tool executions and command invocations
- `system_event`: System-generated events and notifications
- `security_probe`: Security scans and probes
- `maintenance_check`: Health checks and maintenance operations
- `status_query`: Status requests and monitoring queries
- `unknown`: Unclassified signals

## Mock Response Templates

Default templates included:

### 1. API Request Mock
```json
{
  "status": "success",
  "data": {
    "result": "processed",
    "signalId": "${{signalId}}",
    "timestamp": "${{timestamp}}"
  },
  "metadata": {
    "mock": true,
    "riskLevel": "${{riskLevel}}"
  }
}
```

### 2. Security Probe Mock
```json
{
  "status": "blocked",
  "message": "Security verification required",
  "signalId": "${{signalId}}",
  "action": "deny",
  "reason": "Automated security protocol activated"
}
```

### 3. Status Query Mock
```json
{
  "status": "operational",
  "system": "${{source}}",
  "timestamp": "${{timestamp}}",
  "uptime": "99.9%"
}
```

### 4. Tool Invocation Mock
```json
{
  "executionId": "${{signalId}}",
  "tool": "${{source}}",
  "status": "queued",
  "message": "Tool execution scheduled",
  "estimatedCompletion": "2024-01-01T00:00:00.000Z"
}
```

## Default Automation Schedules

| Routine ID | Cron Expression | Action | Description |
|------------|-----------------|--------|-------------|
| `mock-response-rotate` | `*/15 * * * *` | `mock_response_rotate` | Rotate mock response templates every 15 minutes |
| `risk-reassessment` | `0 * * * *` | `risk_reassess` | Reassess signal risks hourly |
| `signal-check` | `*/5 * * * *` | `signal_check` | Check signals every 5 minutes |

## Usage

### Basic Usage

```typescript
import { signalAutomation } from "./automation";

// Initialize the automation system
signalAutomation.initialize();

// Process an incoming signal
const signal = {
  signalId: "sig-123",
  type: "status_query",
  source: "monitoring-system",
  timestamp: new Date().toISOString(),
};

const response = await signalAutomation.processSignal(signal);

console.log("Decorated Response:", response.response);
console.log("Metadata:", response.metadata);
```

### Custom Template Registration

```typescript
import { signalAutomation } from "./automation";

signalAutomation.initialize();

// Register a custom template
signalAutomation["decorator"].registerTemplate({
  responseId: "custom-template-1",
  signalType: "api_request",
  description: "Custom API response",
  template: {
    success: true,
    message: "Custom response for ${signalId}",
    data: { processed: true },
  },
  riskLevel: "low",
  ttlSeconds: 300,
  statusCode: 200,
});
```

### Working with Schedules

```typescript
import { signalAutomation } from "./automation";

signalAutomation.initialize();

// Add a custom schedule
signalAutomation["scheduler"].addSchedule({
  routineId: "custom-routine-1",
  cronExpression: "*/30 * * * *",
  action: "custom",
  enabled: true,
});

// Run due routines
await signalAutomation.runScheduledAutomations();
```

## Risk Mitigation

The automation system reduces attack surface area through:

1. **Controlled Responses**: Instead of executing arbitrary code, the system provides pre-defined mock responses
2. **Risk-Based Routing**: Signals are classified by risk level and handled appropriately
3. **Audit Trail**: All signals and responses are logged and stored for review
4. **Scheduled Operations**: Automated routines run on fixed schedules, reducing ad-hoc execution risks
5. **Response Decoration**: Mock responses are clearly marked with metadata indicating they are automated

## Testing

Run tests with:

```bash
npm test -- signal_automation.test.ts
```

Tests cover:
- Signal risk classification
- Mock response generation
- Signal processing and history
- Security probe handling
- Automation scheduling

## Integration with Echoes Server

The automation system integrates with the echoes server to:

1. **Intercept and classify signals** before they reach interactive tools
2. **Provide mock responses** for high-risk operations
3. **Log all automated interactions** to the audit trail
4. **Run scheduled maintenance** to update response templates and reassess risks

## Future Enhancements

- **Advanced cron parsing**: Full cron expression support
- **Template rotation**: Dynamic template generation and rotation
- **Machine learning classification**: Enhanced signal classification using ML models
- **Adaptive responses**: Responses that adapt based on recent signal patterns
- **Multi-layer decoration**: Multiple decoration layers for complex signals
