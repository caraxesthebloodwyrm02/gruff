/**
 * Signal Automation Module
 *
 * Exports automation system components for signal handling with decorated mock responses.
 */

export * from "./signal_automation.js";
