/**
 * Tests for Signal Automation System
 */

import { describe, it, expect, beforeEach } from "vitest";
import { SignalAutomationEngine, SignalRiskClassifier } from "./signal_automation.js";

describe("SignalRiskClassifier", () => {
  const classifier = new SignalRiskClassifier();

  it("classifies critical risk signals", () => {
    const criticalSignal = {
      signalId: "test-1",
      type: "api_request",
      source: "cli",
      timestamp: new Date().toISOString(),
      payload: { command: "sudo rm -rf /" },
    };
    expect(classifier.classifySignal(criticalSignal)).toBe("critical");
  });

  it("classifies high risk signals", () => {
    const highSignal = {
      signalId: "test-2",
      type: "tool_invocation",
      source: "file_manager",
      timestamp: new Date().toISOString(),
      payload: { action: "delete", path: "/etc/config" },
    };
    expect(classifier.classifySignal(highSignal)).toBe("high");
  });

  it("classifies medium risk signals", () => {
    const mediumSignal = {
      signalId: "test-3",
      type: "status_query",
      source: "monitor",
      timestamp: new Date().toISOString(),
      payload: { action: "check" },
    };
    expect(classifier.classifySignal(mediumSignal)).toBe("medium");
  });

  it("classifies low risk signals", () => {
    const lowSignal = {
      signalId: "test-4",
      type: "system_event",
      source: "heartbeat",
      timestamp: new Date().toISOString(),
    };
    expect(classifier.classifySignal(lowSignal)).toBe("low");
  });
});

describe("SignalAutomationEngine", () => {
  let engine: SignalAutomationEngine;

  beforeEach(() => {
    engine = new SignalAutomationEngine();
    engine.initialize();
  });

  it("initializes with default templates", () => {
    const status = engine.getAutomationStatus();
    expect(status.schedules.length).toBeGreaterThan(0);
    expect(status.running).toBe(true);
  });

  it("processes signals with decorated responses", async () => {
    const signal = {
      signalId: "test-signal-1",
      type: "status_query",
      source: "monitor",
      timestamp: new Date().toISOString(),
    };

    const response = await engine.processSignal(signal);

    expect(response.metadata).toBeDefined();
    expect(response.metadata.signalId).toBe(signal.signalId);
    expect(response.metadata.isMock).toBe(true);
    expect(response.metadata.riskLevel).toBeDefined();
    expect(response.response).toBeDefined();
  });

  it("stores signal history", async () => {
    const signal1 = {
      signalId: "test-signal-2",
      type: "api_request",
      source: "cli",
      timestamp: new Date().toISOString(),
    };

    const signal2 = {
      signalId: "test-signal-3",
      type: "tool_invocation",
      source: "editor",
      timestamp: new Date().toISOString(),
    };

    await engine.processSignal(signal1);
    await engine.processSignal(signal2);

    const history = engine.getSignalHistory();
    expect(history.length).toBe(2);
    expect(history[0].signalId).toBe("test-signal-3");
    expect(history[1].signalId).toBe("test-signal-2");
  });

  it("handles security probe signals appropriately", async () => {
    const securitySignal = {
      signalId: "test-security-1",
      type: "security_probe",
      source: "unknown",
      timestamp: new Date().toISOString(),
      payload: { action: "scan" },
    };

    const response = await engine.processSignal(securitySignal);

    expect(response.metadata.riskLevel).toBe("critical");
    const resp = response.response as Record<string, unknown>;
    expect(resp.status).toBe("blocked");
    expect(resp.action).toBe("deny");
  });

  it("checks due routines", async () => {
    const dueRoutines = await engine["scheduler"].checkDueRoutines(new Date());
    expect(dueRoutines.length).toBeGreaterThan(0);
  });
});
