/**
 * Signal Automation System with Decorated Mock Responses
 *
 * Provides automated signal handling with mock response generation to reduce
 * attack surface area and mitigate risks from wide-open interactive tools.
 *
 * Features:
 * - Scheduled automation routines
 * - Signal type classification and routing
 * - Decorated mock response generation
 * - Risk-based response strategies
 * - Audit trail integration
 */

import { generateId } from "@cascade/shared-types/id";
import { McpLogger } from "@cascade/shared-types/mcp-logger";
import type { TraceContext } from "@cascade/shared-types/trace-context";

// ── Constants ──

const SERVER_NAME = "echoes-server";
const logger = new McpLogger(SERVER_NAME);

// ── Types ──

export type SignalType =
  | "api_request"
  | "tool_invocation"
  | "system_event"
  | "security_probe"
  | "maintenance_check"
  | "status_query"
  | "unknown";

export type RiskLevel = "critical" | "high" | "medium" | "low" | "none";

export interface SignalMetadata {
  signalId: string;
  type: SignalType;
  source: string;
  timestamp: string;
  payload?: Record<string, unknown>;
  traceContext?: TraceContext;
  riskLevel?: RiskLevel;
}

export type TemplateResult = string | Record<string, unknown>;

export interface MockResponseTemplate {
  responseId: string;
  signalType: SignalType;
  description: string;
  template: string | TemplateResult | ((signal: SignalMetadata) => TemplateResult);
  riskLevel: RiskLevel;
  ttlSeconds: number;
  headers?: Record<string, string>;
  statusCode: number;
}

export interface AutomationSchedule {
  routineId: string;
  cronExpression: string;
  action: "signal_check" | "mock_response_rotate" | "risk_reassess" | "custom";
  enabled: boolean;
  lastRun?: string;
  nextRun?: string;
}

export interface DecoratedResponse {
  response: string | Record<string, unknown>;
  metadata: {
    signalId: string;
    responseId: string;
    timestamp: string;
    isMock: boolean;
    riskLevel: RiskLevel;
    decoration: {
      pattern: string;
      confidence: number;
      source: string;
    };
  };
}

// ── Signal Risk Classifier ──

export class SignalRiskClassifier {
  private static CRITICAL_KEYWORDS = [
    "root", "sudo", "admin", "password", "secret", "token",
    "execute", "shell", "command", "inject", "bypass", "override"
  ];

  private static HIGH_KEYWORDS = [
    "config", "settings", "database", "network", "file", "write",
    "delete", "modify", "update", "access", "permission"
  ];

  private static MEDIUM_KEYWORDS = [
    "read", "query", "status", "info", "list", "get", "check", "verify"
  ];

  classifySignal(signal: SignalMetadata): RiskLevel {
    // Fast path: security_probe signals are always critical
    if (signal.type === "security_probe") {
      return "critical";
    }

    const payloadStr = signal.payload
      ? typeof signal.payload === "string"
        ? signal.payload
        : JSON.stringify(signal.payload)
      : "";
    const combinedText = `${signal.source} ${signal.type} ${payloadStr}`.toLowerCase();

    // Critical risk detection
    if (SignalRiskClassifier.CRITICAL_KEYWORDS.some(kw => combinedText.includes(kw))) {
      return "critical";
    }

    // High risk detection
    if (SignalRiskClassifier.HIGH_KEYWORDS.some(kw => combinedText.includes(kw))) {
      return "high";
    }

    // Medium risk detection
    if (SignalRiskClassifier.MEDIUM_KEYWORDS.some(kw => combinedText.includes(kw))) {
      return "medium";
    }

    return "low";
  }
}

// ── Mock Response Decorator ──

export class MockResponseDecorator {
  private templates: MockResponseTemplate[];
  private classifier: SignalRiskClassifier;

  constructor() {
    this.templates = [];
    this.classifier = new SignalRiskClassifier();
  }

  registerTemplate(template: MockResponseTemplate): void {
    this.templates.push(template);
  }

  generateDecoratedResponse(signal: SignalMetadata): DecoratedResponse {
    const riskLevel = this.classifier.classifySignal(signal);
    const responseId = generateId("resp");

    // Find appropriate template
    const template = this.templates
      .find(t => t.signalType === signal.type || t.signalType === "unknown");

    let response: string | Record<string, unknown>;

    if (template) {
      if (typeof template.template === "function") {
        response = template.template(signal);
      } else {
        response = this.interpolateTemplate(template.template, signal);
      }
    } else {
      // Default mock response
      response = {
        status: "processed",
        message: `Signal ${signal.signalId} received and handled`,
        signalType: signal.type,
        timestamp: new Date().toISOString(),
      };
    }

    return {
      response,
      metadata: {
        signalId: signal.signalId,
        responseId,
        timestamp: new Date().toISOString(),
        isMock: true,
        riskLevel,
        decoration: {
          pattern: template?.description || "default_mock",
          confidence: this.getConfidenceScore(riskLevel),
          source: "signal_automation",
        },
      },
    };
  }

  private interpolateTemplate(template: string | TemplateResult, signal: SignalMetadata): TemplateResult {
    if (typeof template !== "string") {
      return template;
    }
    return template
      .replace(/\${\{signalId\}\}/g, signal.signalId)
      .replace(/\${\{type\}\}/g, signal.type)
      .replace(/\${\{source\}\}/g, signal.source)
      .replace(/\${\{timestamp\}\}/g, signal.timestamp)
      .replace(/\${\{riskLevel\}\}/g, signal.riskLevel || "unknown");
  }

  private getConfidenceScore(riskLevel: RiskLevel): number {
    const scores: Record<RiskLevel, number> = {
      critical: 0.95,
      high: 0.85,
      medium: 0.75,
      low: 0.65,
      none: 0.55,
    };
    return scores[riskLevel] || 0.6;
  }
}

// ── Automation Scheduler ──

export class AutomationScheduler {
  private schedules: AutomationSchedule[];
  private running: boolean;

  isRunning(): boolean {
    return this.running;
  }

  constructor() {
    this.schedules = [];
    this.running = false;
  }

  addSchedule(schedule: AutomationSchedule): void {
    this.schedules.push(schedule);
  }

  start(): void {
    if (this.running) {
      logger.info("Automation scheduler already running");
      return;
    }
    this.running = true;
    logger.info("Automation scheduler started");
  }

  stop(): void {
    this.running = false;
    logger.info("Automation scheduler stopped");
  }

  getScheduledRoutines(): AutomationSchedule[] {
    return this.schedules.filter(s => s.enabled);
  }

  async checkDueRoutines(currentTime: Date = new Date()): Promise<AutomationSchedule[]> {
    const dueRoutines: AutomationSchedule[] = [];

    for (const schedule of this.schedules) {
      if (!schedule.enabled) continue;

      try {
        // Simple cron-like checking (can be enhanced with cron-parser)
        if (this.isCronDue(schedule.cronExpression, currentTime)) {
          dueRoutines.push(schedule);
        }
      } catch (error) {
        logger.error(`Error checking schedule ${schedule.routineId}: ${error}`);
      }
    }

    return dueRoutines;
  }

  private isCronDue(cronExpression: string, date: Date): boolean {
    // Parse cron expression: "*/5 * * * *" (every 5 minutes)
    // or "0 * * * *" (hourly) or "0 0 * * *" (daily)
    const parts = cronExpression.split(" ");
    if (parts.length !== 5) {
      return false;
    }

    const [minutes, hours] = parts;

    // Check minutes
    if (minutes !== "*" && minutes !== "*/5" && minutes !== "*/10" && minutes !== "*/15") {
      const minNum = parseInt(minutes);
      if (date.getMinutes() !== minNum) {
        return false;
      }
    }

    // Check hours
    if (hours !== "*") {
      const hourNum = parseInt(hours);
      if (date.getHours() !== hourNum) {
        return false;
      }
    }

    return true;
  }
}

// ── Signal Automation Engine ──

export class SignalAutomationEngine {
  private decorator: MockResponseDecorator;
  private scheduler: AutomationScheduler;
  private signalHistory: SignalMetadata[];
  private maxHistory: number;

  constructor() {
    this.decorator = new MockResponseDecorator();
    this.scheduler = new AutomationScheduler();
    this.signalHistory = [];
    this.maxHistory = 1000;
  }

  initialize(): void {
    this.registerDefaultTemplates();
    this.setupDefaultSchedules();
    this.scheduler.start();
  }

  private registerDefaultTemplates(): void {
    // API Request mock template
    this.decorator.registerTemplate({
      responseId: "template-api-generic",
      signalType: "api_request",
      description: "Generic API request mock",
      template: {
        status: "success",
        data: {
          result: "processed",
          signalId: "${{signalId}}",
          timestamp: "${{timestamp}}",
        },
        metadata: {
          mock: true,
          riskLevel: "${{riskLevel}}",
        },
      },
      riskLevel: "medium",
      ttlSeconds: 300,
      statusCode: 200,
    });

    // Security probe mock template
    this.decorator.registerTemplate({
      responseId: "template-security-probe",
      signalType: "security_probe",
      description: "Security probe deflection",
      template: (signal) => ({
        status: "blocked",
        message: "Security verification required",
        signalId: signal.signalId,
        action: "deny",
        reason: "Automated security protocol activated",
      }),
      riskLevel: "critical",
      ttlSeconds: 60,
      statusCode: 403,
    });

    // Status query mock template
    this.decorator.registerTemplate({
      responseId: "template-status-query",
      signalType: "status_query",
      description: "System status response",
      template: {
        status: "operational",
        system: "${{source}}",
        timestamp: "${{timestamp}}",
        uptime: "99.9%",
      },
      riskLevel: "low",
      ttlSeconds: 60,
      statusCode: 200,
    });

    // Tool invocation mock template
    this.decorator.registerTemplate({
      responseId: "template-tool-invocation",
      signalType: "tool_invocation",
      description: "Tool execution mock",
      template: (signal) => ({
        executionId: signal.signalId,
        tool: signal.source,
        status: "queued",
        message: "Tool execution scheduled",
        estimatedCompletion: new Date(Date.now() + 5000).toISOString(),
      }),
      riskLevel: "medium",
      ttlSeconds: 120,
      statusCode: 202,
    });
  }

  private setupDefaultSchedules(): void {
    // Rotate mock responses every 15 minutes
    this.scheduler.addSchedule({
      routineId: "mock-response-rotate",
      cronExpression: "*/15 * * * *",
      action: "mock_response_rotate",
      enabled: true,
    });

    // Reassess signal risks hourly
    this.scheduler.addSchedule({
      routineId: "risk-reassessment",
      cronExpression: "0 * * * *",
      action: "risk_reassess",
      enabled: true,
    });

    // Signal check every 5 minutes
    this.scheduler.addSchedule({
      routineId: "signal-check",
      cronExpression: "*/5 * * * *",
      action: "signal_check",
      enabled: true,
    });
  }

  async processSignal(signal: SignalMetadata): Promise<DecoratedResponse> {
    // Classify and decorate the signal
    const response = this.decorator.generateDecoratedResponse(signal);

    // Store in history
    this.storeSignal(signal);

    // Log the automated response
    logger.info(`Processed signal ${signal.signalId} with mock response`, {
      signalType: signal.type,
      riskLevel: response.metadata.riskLevel,
      responseId: response.metadata.responseId,
    });

    return response;
  }

  private storeSignal(signal: SignalMetadata): void {
    this.signalHistory.push(signal);
    if (this.signalHistory.length > this.maxHistory) {
      this.signalHistory = this.signalHistory.slice(-this.maxHistory);
    }
  }

  async runScheduledAutomations(): Promise<void> {
    const now = new Date();
    const dueRoutines = await this.scheduler.checkDueRoutines(now);

    for (const routine of dueRoutines) {
      await this.executeRoutine(routine);
      routine.lastRun = now.toISOString();
    }
  }

  private async executeRoutine(routine: AutomationSchedule): Promise<void> {
    logger.info(`Executing automation routine: ${routine.routineId}`);

    switch (routine.action) {
      case "signal_check":
        await this.handleSignalCheck();
        break;
      case "mock_response_rotate":
        await this.handleMockResponseRotation();
        break;
      case "risk_reassess":
        await this.handleRiskReassessment();
        break;
      default:
        logger.warn(`Unknown routine action: ${routine.action}`);
    }
  }

  private async handleSignalCheck(): Promise<void> {
    logger.info("Performing signal check", {
      signalCount: this.signalHistory.length,
    });
  }

  private async handleMockResponseRotation(): Promise<void> {
    logger.info("Rotating mock response templates");
    // In a real implementation, this would refresh templates
    // from a secure source or regenerate them
  }

  private async handleRiskReassessment(): Promise<void> {
    logger.info("Reassessing signal risks", {
      historySize: this.signalHistory.length,
    });
    // Analyze recent signals for pattern changes
  }

  getSignalHistory(): SignalMetadata[] {
    return [...this.signalHistory].reverse();
  }

  getAutomationStatus(): {
    schedules: AutomationSchedule[];
    signalCount: number;
    running: boolean;
  } {
    return {
      schedules: this.scheduler.getScheduledRoutines(),
      signalCount: this.signalHistory.length,
      running: this.scheduler.isRunning(),
    };
  }
}

// ── Export singleton instance ──

export const signalAutomation = new SignalAutomationEngine();
