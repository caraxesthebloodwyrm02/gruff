/**
 * Envelope — phased test pipeline with modulation gates.
 *
 * Plugin: phasing — ordered fold execution with inter-fold context.
 * Plugin: modulation — failure thresholds control advancement/halting.
 *
 * Usage:
 *   import { envelope, FOLD_1_CORE, FOLD_2_ANALYSIS, FOLD_3_INTEGRATION } from "./envelope";
 *   const result = await envelope([FOLD_1_CORE, FOLD_2_ANALYSIS, FOLD_3_INTEGRATION]);
 */

import { execSync } from "child_process";
import path from "path";

// ── Types ────────────────────────────────────────────────────────────────────

export interface PhaseEnvelope {
  id: string;
  fold: 1 | 2 | 3;
  category: "core" | "analysis" | "integration";
  files: string[];
  modulation: {
    maxFailures: number;
    hardHaltOn: string[];
    requirePreviousFold: boolean;
  };
}

export interface FailureEntry {
  test: string;
  cause: string;
  category: "env-coupling" | "cascading" | "env-path" | "fixture-missing" | "logic" | "unknown";
}

export interface PhaseResult {
  envelope: PhaseEnvelope;
  passed: number;
  failed: number;
  duration_ms: number;
  failures: FailureEntry[];
  status: "green" | "yellow" | "red";
  advanceable: boolean;
  rawOutput: string;
}

export interface PipelineResult {
  folds: PhaseResult[];
  overall: "pass" | "warn" | "fail";
  recommendations: string[];
  totalPassed: number;
  totalFailed: number;
  totalDuration_ms: number;
}

export interface EnvelopeOptions {
  verbose?: boolean;
  haltOnFirstRed?: boolean;
  cwd?: string;
  reporter?: string;
}

// ── Fold definitions ─────────────────────────────────────────────────────────

export const FOLD_1_CORE: PhaseEnvelope = {
  id: "ori-fold-1-core",
  fold: 1,
  category: "core",
  files: ["tests/smoke.test.ts", "tests/registry.test.ts", "tests/executor.test.ts"],
  modulation: {
    maxFailures: 4,
    hardHaltOn: ["registers expected tools", "reports healthy status"],
    requirePreviousFold: false,
  },
};

export const FOLD_2_ANALYSIS: PhaseEnvelope = {
  id: "ori-fold-2-analysis",
  fold: 2,
  category: "analysis",
  files: ["tests/reporter.test.ts", "tests/heatmap.test.ts", "tests/anti-pattern.test.ts"],
  modulation: {
    maxFailures: 0,
    hardHaltOn: ["*"],
    requirePreviousFold: true,
  },
};

export const FOLD_3_INTEGRATION: PhaseEnvelope = {
  id: "ori-fold-3-integration",
  fold: 3,
  category: "integration",
  files: ["tests/threat-model.test.ts", "tests/notebook.test.ts", "tests/interop.test.ts"],
  modulation: {
    maxFailures: 6,
    hardHaltOn: ["notebook_add creates a note", "interop > reads echoes audit"],
    requirePreviousFold: true,
  },
};

// ── Parsing ──────────────────────────────────────────────────────────────────

interface ParsedOutput {
  passed: number;
  failed: number;
  duration_ms: number;
  failedTests: string[];
}

function parseVitestOutput(raw: string): ParsedOutput {
  const passedMatch = raw.match(/(\d+)\s+passed/);
  const failedMatch = raw.match(/(\d+)\s+failed/);
  const durationMatch = raw.match(/Duration\s+(\d+)ms/);

  const failedTests: string[] = [];
  const failLines = raw.split("\n").filter((l) => l.includes("FAIL ") || l.includes("× "));
  for (const line of failLines) {
    const cleaned = line.replace(/^.*[×✗]\s*/, "").replace(/^\s*FAIL\s*/, "").trim();
    if (cleaned) failedTests.push(cleaned);
  }

  return {
    passed: passedMatch ? parseInt(passedMatch[1], 10) : 0,
    failed: failedMatch ? parseInt(failedMatch[1], 10) : 0,
    duration_ms: durationMatch ? parseInt(durationMatch[1], 10) : 0,
    failedTests,
  };
}

function classifyFailure(testName: string, output: string): FailureEntry["category"] {
  if (output.includes("ENOENT") || output.includes("no such file")) return "fixture-missing";
  if (output.includes("ECONNREFUSED") || output.includes("ERR_MODULE_NOT_FOUND")) return "env-coupling";
  if (testName.includes("retrieves") || testName.includes("updated after")) return "cascading";
  if (output.includes("expected") && output.includes("path")) return "env-path";
  return "unknown";
}

// ── Core engine ──────────────────────────────────────────────────────────────

function runFold(env: PhaseEnvelope, options: EnvelopeOptions): PhaseResult {
  const cwd = options.cwd ?? process.cwd();
  const reporter = options.reporter ?? "verbose";
  const fileArgs = env.files.join(" ");
  const cmd = `npx vitest run ${fileArgs} --reporter=${reporter}`;

  let rawOutput: string;
  try {
    rawOutput = execSync(cmd, {
      cwd,
      encoding: "utf-8",
      timeout: 60_000,
      env: { ...process.env, FORCE_COLOR: "0" },
    });
  } catch (err: any) {
    rawOutput = err.stdout ?? err.message ?? "";
  }

  const parsed = parseVitestOutput(rawOutput);

  // Classify failures
  const failures: FailureEntry[] = parsed.failedTests.map((test) => ({
    test,
    cause: test,
    category: classifyFailure(test, rawOutput),
  }));

  // Determine status via modulation rules
  let status: PhaseResult["status"] = "green";
  let advanceable = true;

  if (parsed.failed > 0) {
    // Check hard-halt patterns
    const hardHalt = env.modulation.hardHaltOn.some((pattern) => {
      if (pattern === "*") return parsed.failed > 0;
      return parsed.failedTests.some((t) => t.includes(pattern));
    });

    if (hardHalt) {
      status = "red";
      advanceable = false;
    } else if (parsed.failed <= env.modulation.maxFailures) {
      status = "yellow";
      advanceable = true;
    } else {
      status = "red";
      advanceable = false;
    }
  }

  return {
    envelope: env,
    passed: parsed.passed,
    failed: parsed.failed,
    duration_ms: parsed.duration_ms,
    failures,
    status,
    advanceable,
    rawOutput,
  };
}

// ── Public API ───────────────────────────────────────────────────────────────

/**
 * Execute a phased test pipeline with modulation gates.
 *
 * Modulation rules:
 *   1. Run fold N
 *   2. If hardHaltOn pattern matched in failures → status = "red", halt
 *   3. If failed <= maxFailures → status = "yellow", advance
 *   4. If failed === 0 → status = "green", advance
 *   5. If fold requires previous fold and previous was red → skip
 *
 * @param folds - Ordered PhaseEnvelope definitions
 * @param options - Runtime configuration
 * @returns PipelineResult with per-fold results and overall verdict
 */
export function envelope(
  folds: PhaseEnvelope[] = [FOLD_1_CORE, FOLD_2_ANALYSIS, FOLD_3_INTEGRATION],
  options: EnvelopeOptions = {},
): PipelineResult {
  const results: PhaseResult[] = [];
  const recommendations: string[] = [];

  for (const fold of folds) {
    // Gate: check previous fold requirement
    if (fold.modulation.requirePreviousFold && results.length > 0) {
      const prev = results[results.length - 1];
      if (!prev.advanceable) {
        // Skip this fold — previous was red
        results.push({
          envelope: fold,
          passed: 0,
          failed: 0,
          duration_ms: 0,
          failures: [],
          status: "red",
          advanceable: false,
          rawOutput: `SKIPPED — previous fold (${prev.envelope.id}) was red.`,
        });
        recommendations.push(`Fix fold ${prev.envelope.fold} before running fold ${fold.fold}`);
        continue;
      }
    }

    const result = runFold(fold, options);
    results.push(result);

    // Generate recommendations from failures
    if (result.failed > 0) {
      const fixtureFailures = result.failures.filter((f) => f.category === "fixture-missing");
      if (fixtureFailures.length > 0) {
        recommendations.push(
          `[Fold ${fold.fold}] Create missing fixture files to resolve ${fixtureFailures.length} failures`,
        );
      }
      const envFailures = result.failures.filter((f) => f.category === "env-coupling");
      if (envFailures.length > 0) {
        recommendations.push(
          `[Fold ${fold.fold}] Mock subprocess/env dependencies to resolve ${envFailures.length} failures`,
        );
      }
    }

    if (options.haltOnFirstRed && result.status === "red") {
      break;
    }
  }

  // Compute overall verdict
  const hasRed = results.some((r) => r.status === "red");
  const hasYellow = results.some((r) => r.status === "yellow");
  const overall = hasRed ? "fail" : hasYellow ? "warn" : "pass";

  return {
    folds: results,
    overall,
    recommendations,
    totalPassed: results.reduce((s, r) => s + r.passed, 0),
    totalFailed: results.reduce((s, r) => s + r.failed, 0),
    totalDuration_ms: results.reduce((s, r) => s + r.duration_ms, 0),
  };
}
